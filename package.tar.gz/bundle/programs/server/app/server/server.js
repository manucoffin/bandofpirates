(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/server.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// Meteor.startup(function () {                                        //
                                                                       //
// });                                                                 //
                                                                       //
// ------------------------------------------------------------------------
// 		COLLECTIONS PUBLICATION                                           //
// ------------------------------------------------------------------------
                                                                       //
Meteor.publish('boats', function () {                                  // 18
	return Boats.find({});                                                // 19
});                                                                    //
                                                                       //
Meteor.publish("userStatus", function () {                             // 22
	return Meteor.users.find({ "status.online": true });                  // 23
});                                                                    //
                                                                       //
Meteor.publish("messages", function () {                               // 26
	return Messages.find({});                                             // 27
});                                                                    //
                                                                       //
// ------------------------------------------------------------------------
// 		CLOUDS HANDLING                                                   //
// ------------------------------------------------------------------------
                                                                       //
var cloudsPositions = [];                                              // 46
for (var i = 0; i < 40; i++) {                                         // 47
	cloudsPositions[i] = { x: Math.random() * 1600, y: Math.random() * 1600 };
};                                                                     //
                                                                       //
// Generate a random wind direction                                    //
var wind = { dx: Math.random() * 2, dy: Math.random() * 2 };           // 52
                                                                       //
var serverUpdate = setInterval(function () {                           // 55
                                                                       //
	for (var i = 0; i < 40; i++) {                                        // 57
		var newX = undefined,                                                // 58
		    newY = undefined;                                                //
                                                                       //
		if (cloudsPositions[i].x < 1600) {                                   // 60
			newX = cloudsPositions[i].x + wind.dx;                              // 62
		} else {                                                             //
			newX = 0;                                                           // 66
		}                                                                    //
                                                                       //
		if (cloudsPositions[i].y < 1600) {                                   // 69
			newY = cloudsPositions[i].y + wind.dy;                              // 71
		} else {                                                             //
			newY = 0;                                                           // 75
		}                                                                    //
                                                                       //
		cloudsPositions[i] = { x: newX, y: newY };                           // 79
	};                                                                    //
                                                                       //
	Streamy.broadcast('clouds_datas', {                                   // 82
		positions: cloudsPositions                                           // 84
	});                                                                   //
}, 300);                                                               //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=server.js.map
